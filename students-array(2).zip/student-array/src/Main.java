public class Main {

	public static void main(String[] args) {
		
studentGroup s=new studentGroup();
s.getFullname();		
//You may test that your code works find here
		//Please check that your code works and has no 
		//compilation problems before to submit
	}

}
